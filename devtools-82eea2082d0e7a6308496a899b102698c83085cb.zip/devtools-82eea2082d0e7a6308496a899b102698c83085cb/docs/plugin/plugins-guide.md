# Plugin Development Guide

> :warning: This page is WIP

::: warning
The API is only available in Vue Devtools 6+
:::

## Architecture

![Vue Devtools Architectue](../assets/vue-devtools-architecture.svg)
