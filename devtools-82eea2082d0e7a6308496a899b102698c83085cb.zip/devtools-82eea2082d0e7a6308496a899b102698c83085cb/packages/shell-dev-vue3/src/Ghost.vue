<script>
export default {
  devtools: {
    hide: true
  }
}
</script>

<template>
  I'm a ghost component that will be not displayed in the devtools
</template>
