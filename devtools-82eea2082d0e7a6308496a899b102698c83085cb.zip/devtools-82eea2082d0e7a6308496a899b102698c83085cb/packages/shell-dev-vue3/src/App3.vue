<template>
  <Hello />
</template>

<script>
import Hello from './Hello'

export default {
  components: {
    Hello
  },

  data () {
    return {
      count: 0
    }
  }
}
</script>
