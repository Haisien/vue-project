<template>
  <div>
    <p>Hello from route 2</p>
  </div>
</template>

<script>
export default {

}
</script>
