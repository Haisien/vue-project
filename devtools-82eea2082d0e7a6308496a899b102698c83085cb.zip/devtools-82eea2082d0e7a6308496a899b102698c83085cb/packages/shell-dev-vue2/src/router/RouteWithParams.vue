<template>
  <div>
    <p>Hello from route with params: Username: {{ $route.params.username }}, Id: {{ $route.params.id }}</p>
  </div>
</template>

<script>
export default {

}
</script>
